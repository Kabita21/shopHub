
from .views import Blog,Blog_details
from django.urls import include, path
urlpatterns = [
    
    path('blog/', Blog, name='blog'),
    path('blogDetails/', Blog_details, name='blogDetails'),
]
